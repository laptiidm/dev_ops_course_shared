#!/bin/bash

API_KEY="12cd01c1b1msh121d5642d7f5fe2p1c574bjsnbf5f88c224bd"
API_URL="https://weatherapi-com.p.rapidapi.com/current.json?q=Kyiv&units=metric&lang=en"

# Местоположение для запроса данных о погоде
LATITUDE="50.4501"
LONGITUDE="30.5234"

# Функция для получения данных о погоде
get_weather_data() {
     response=$(curl -s --request GET --url 'https://weatherapi-com.p.rapidapi.com/current.json?q=Kyiv&units=metric&lang=en' --header 'X-RapidAPI-Host: weatherapi-com.p.rapidapi.com' --header 'X-RapidAPI-Key: 12cd01c1b1msh121d5642d7f5fe2p1c574bjsnbf5f88c224bd')

    if [ $? -eq 0 ]; then
        # Извлекаем необходимые поля из JSON-ответа (например, температуру и описание погоды)
        #echo "$response"
        time_date_current=$(echo "$response" | jq -r '.location.localtime')
        temperature=$(echo "$response" | jq -r '.current.temp_c')
        general=$(echo "$response" | jq -r '.current.condition.text')
        country=$(echo "$response" | jq -r '.location.country')
        city=$(echo "$response" | jq -r '.location.name')
        wind=$(echo "$response" | jq -r '.current.wind_kph')
        # Создаем текстовую строку с данными
        weather_info="Країна: $country\nМісто: $city\nТемпература: $temperature °C\nШвидкість вітру: $wind\nОпис: $general\n"

        # Записываем данные в файл (например, weather.txt)
        echo -e "$weather_info" >> info_weather.txt

        echo "Получены данные о погоде и записаны в файл weather.txt"
    else
        echo "Ошибка при запросе данных о погоде"
    fi
}

while true; do
        get_weather_data
        sleep 2m
done


